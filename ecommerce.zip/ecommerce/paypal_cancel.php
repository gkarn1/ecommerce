
<html>
	<head>
		<title>Payment Cancell!</title>
		
		
	</head>


<body>

	<h2>Payment was cancelled!<h2/>
	<h3>Your payment was not successful! Try again!</h3>
	<h3><a href="http://www.robotechfront.com/myshop">Back</a></h3>
	


</body>
</html>	