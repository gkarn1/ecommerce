<?php 
session_start(); 
?>



<html>
	<head>
		<title>Payment Successful!</title>
		
		
	</head>


<body>

	<h2>Payment was successfully done!<h2/>
	<h3>Your payment was successful!</h3>
	<h3><a href="http://www.robotechfront.com/my_account">Back</a></h3>
	


</body>
</html>	